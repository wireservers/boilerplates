// Keeping default Expo Metro config
const { getDefaultConfig } = require('expo/metro-config');
module.exports = getDefaultConfig(__dirname);