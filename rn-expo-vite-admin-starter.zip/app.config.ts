import { ExpoConfig } from "expo/config";

export default ({ config }: { config: ExpoConfig }) => ({
  name: "RN Expo Vite Admin",
  slug: "rn-expo-vite-admin",
  scheme: process.env.APP_SCHEME || "rnav",
  ios: {
    supportsTablet: true
  },
  android: {
    adaptiveIcon: {
      foregroundImage: "./assets/adaptive-icon.png",
      backgroundColor: "#ffffff"
    },
    package: "com.example.rnviteadmin"
  },
  web: {
    bundler: "metro"
  },
  extra: {
    supabaseUrl: process.env.SUPABASE_URL,
    supabaseAnonKey: process.env.SUPABASE_ANON_KEY
  }
});
