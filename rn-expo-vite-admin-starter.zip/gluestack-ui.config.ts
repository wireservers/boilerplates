import { config } from "@gluestack-ui/config";
export default config;
