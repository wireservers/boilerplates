import { AppRegistry } from "react-native";
import App from "../App";
import "react-native-url-polyfill/auto";

AppRegistry.registerComponent("App", () => App);
AppRegistry.runApplication("App", { rootTag: document.getElementById("root") });
