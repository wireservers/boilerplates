import React from "react";
import { GluestackUIProvider } from "@gluestack-ui/themed";
import gluestackConfig from "./gluestack-ui.config";
import { AuthProvider } from "./src/providers/AuthProvider";
import { RootNavigator } from "./src/navigation/RootNavigator";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View } from "react-native";

export default function App() {
  return (
    <GluestackUIProvider config={gluestackConfig}>
      <AuthProvider>
        <SafeAreaProvider>
          <View style={{ flex: 1 }}>
            <RootNavigator />
          </View>
        </SafeAreaProvider>
      </AuthProvider>
    </GluestackUIProvider>
  );
}
