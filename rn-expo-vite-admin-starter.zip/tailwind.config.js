/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./App.{js,jsx,ts,tsx}",
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0f9ff",
          100: "#d1fae5",
          200: "#a7f3d0",
          300: "#6ee7b7",
          400: "#34d399",
          500: "#10b981",
          600: "#0ea5e9",
          700: "#0284c7",
          800: "#0369a1",
          900: "#065f46"
        },
        primary: {
          600: "#0ea5e9"
        },
        success: {
          600: "#10b981"
        }
      }
    }
  },
  plugins: []
};
