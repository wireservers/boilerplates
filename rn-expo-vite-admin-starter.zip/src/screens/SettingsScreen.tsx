import React from "react";
import { Box, Text } from "@gluestack-ui/themed";

export default function SettingsScreen() {
  return (
    <Box className="flex-1 p-4">
      <Text className="text-2xl font-semibold mb-2">Settings</Text>
      <Text className="text-gray-500">Coming soon.</Text>
    </Box>
  );
}
