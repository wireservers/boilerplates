import React, { useEffect, useState } from "react";
import { Box, Button, Input, InputField, Text, VStack, HStack } from "@gluestack-ui/themed";
import { supabase } from "../providers/SupabaseClient";
import { useNavigation, useRoute } from "@react-navigation/native";

export default function UserFormScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { mode, id } = route.params || {};
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState("user");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      if (mode !== "edit") return;
      const { data, error } = await supabase.from("profiles").select("*").eq("id", id).single();
      if (error) { setErr(error.message); return; }
      setEmail(data.email || "");
      setFullName(data.full_name || "");
      setRole(data.role || "user");
      setAvatarUrl(data.avatar_url || "");
    };
    init();
  }, [id, mode]);

  const save = async () => {
    setErr(null);
    try {
      if (mode === "create") {
        // In a real app, user creation occurs via auth sign-up then profile insert.
        // Here, allow insert for demonstration when RLS permits owner insert.
        const { error } = await supabase.from("profiles").insert({ id: crypto.randomUUID(), email, full_name: fullName, role, avatar_url: avatarUrl });
        if (error) throw error;
      } else if (mode === "edit") {
        const { error } = await supabase.from("profiles").update({ email, full_name: fullName, role, avatar_url: avatarUrl }).eq("id", id);
        if (error) throw error;
      } else if (mode === "delete") {
        const { error } = await supabase.from("profiles").delete().eq("id", id);
        if (error) throw error;
      }
      nav.goBack();
    } catch (e: any) {
      setErr(e.message);
    }
  };

  const title = mode === "create" ? "Create User" : mode === "edit" ? "Edit User" : "Delete User";

  return (
    <Box className="flex-1 p-4">
      <Text className="text-2xl font-semibold mb-2">{title}</Text>
      {err ? <Text className="text-red-600 mb-2">{err}</Text> : null}
      {mode !== "delete" ? (
        <VStack space="md">
          <Input><InputField value={email} onChangeText={setEmail} placeholder="email"/></Input>
          <Input><InputField value={fullName} onChangeText={setFullName} placeholder="full name"/></Input>
          <Input><InputField value={role} onChangeText={setRole} placeholder="role"/></Input>
          <Input><InputField value={avatarUrl} onChangeText={setAvatarUrl} placeholder="avatar url"/></Input>
        </VStack>
      ) : (
        <Text className="text-gray-600">Are you sure you want to delete this user?</Text>
      )}
      <HStack className="gap-2 mt-4">
        <Button className="bg-primary-600" onPress={save}>{mode === "delete" ? "Confirm Delete" : "Save"}</Button>
        <Button variant="outline" onPress={() => nav.goBack()}>Cancel</Button>
      </HStack>
    </Box>
  );
}
