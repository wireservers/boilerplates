import React, { useState } from "react";
import { useAuth } from "../providers/AuthProvider";
import { Box, Button, Input, InputField, Text, VStack } from "@gluestack-ui/themed";

export default function ForgotPasswordScreen() {
  const { sendReset } = useAuth();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    setErr(null);
    try {
      await sendReset(email);
      setSent(true);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <Box className="flex-1 items-center justify-center p-6">
      <VStack className="w-full max-w-md bg-white rounded-2xl p-6 shadow">
        <Text className="text-xl font-semibold mb-2">Reset your password</Text>
        <Input>
          <InputField value={email} onChangeText={setEmail} placeholder="you@company.com"/>
        </Input>
        {err ? <Text className="text-red-600 mt-2">{err}</Text> : null}
        {sent ? <Text className="text-green-600 mt-2">Check your email for the reset link.</Text> : null}
        <Button className="bg-primary-600 mt-3" onPress={submit}>Send reset link</Button>
      </VStack>
    </Box>
  );
}
