import React, { useMemo, useState, useEffect } from "react";
import { Box, Button, Input, InputField, Text, VStack } from "@gluestack-ui/themed";
import { useAuth } from "../providers/AuthProvider";
import * as Linking from "expo-linking";

function useAccessTokenFromUrl() {
  return useMemo(() => {
    const url = Linking.useURL() || (typeof window !== "undefined" ? window.location.href : "");
    if (!url) return null;
    const hash = url.split("#")[1] || "";
    const params = new URLSearchParams(hash);
    return params.get("access_token");
  }, []);
}

export default function ResetPasswordScreen() {
  const { finishReset } = useAuth();
  const token = useAccessTokenFromUrl();
  const [pw, setPw] = useState("");
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    setErr(null);
    try {
      if (!token) throw new Error("Missing reset token from URL.");
      await finishReset(token, pw);
      setOk(true);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <Box className="flex-1 items-center justify-center p-6">
      <VStack className="w-full max-w-md bg-white rounded-2xl p-6 shadow">
        <Text className="text-xl font-semibold mb-2">Set a new password</Text>
        <Input>
          <InputField value={pw} onChangeText={setPw} placeholder="New password" secureTextEntry/>
        </Input>
        {err ? <Text className="text-red-600 mt-2">{err}</Text> : null}
        {ok ? <Text className="text-green-600 mt-2">Password updated. You can now sign in.</Text> : null}
        <Button className="bg-success-600 mt-3" onPress={submit}>Update Password</Button>
      </VStack>
    </Box>
  );
}
