import React, { useEffect, useState } from "react";
import { FlatList } from "react-native";
import { Box, Button, HStack, Input, InputField, Text, VStack } from "@gluestack-ui/themed";
import { supabase } from "../providers/SupabaseClient";
import { useNavigation } from "@react-navigation/native";

type Profile = {
  id: string;
  email: string | null;
  full_name: string | null;
  role: string | null;
  avatar_url: string | null;
};

export default function UsersScreen() {
  const nav = useNavigation<any>();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Profile[]>([]);

  const load = async () => {
    let query = supabase.from("profiles").select("*").limit(50);
    const { data } = await query;
    setRows(data as any || []);
  };

  useEffect(() => { load(); }, []);

  return (
    <VStack className="flex-1 p-4">
      <HStack className="justify-between items-center mb-3">
        <Text className="text-2xl font-semibold">Users</Text>
        <Button className="bg-primary-600" onPress={() => nav.navigate("UserForm", { mode: "create" })}>New</Button>
      </HStack>
      <Box className="mb-3">
        <Input>
          <InputField value={q} onChangeText={setQ} placeholder="Search (client-side demo)"/>
        </Input>
      </Box>

      <FlatList
        data={rows.filter(r => (r.email||"").toLowerCase().includes(q.toLowerCase()))}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Box className="bg-white rounded-xl p-4 mb-2">
            <Text className="font-semibold">{item.full_name || "(no name)"} <Text className="text-gray-500">— {item.email}</Text></Text>
            <HStack className="gap-2 mt-2">
              <Button size="sm" variant="outline" onPress={() => nav.navigate("UserForm", { mode: "edit", id: item.id })}>Edit</Button>
              <Button size="sm" variant="outline" onPress={() => nav.navigate("UserForm", { mode: "delete", id: item.id })}>Delete</Button>
            </HStack>
          </Box>
        )}
      />
    </VStack>
  );
}
