import React, { useEffect, useState } from "react";
import { Box, Button, Input, InputField, Text, VStack } from "@gluestack-ui/themed";
import { supabase } from "../providers/SupabaseClient";
import { useAuth } from "../providers/AuthProvider";

export default function ProfileScreen() {
  const { session } = useAuth();
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      if (!session?.user) return;
      const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).single();
      setEmail(session.user.email || "");
      setFullName(data?.full_name || "");
      setAvatarUrl(data?.avatar_url || "");
    };
    init();
  }, [session?.user?.id]);

  const save = async () => {
    setOk(false); setErr(null);
    try {
      if (!session?.user) throw new Error("No user");
      const { error } = await supabase.from("profiles").upsert({
        id: session.user.id,
        email,
        full_name: fullName,
        avatar_url: avatarUrl
      }, { onConflict: "id" });
      if (error) throw error;
      setOk(true);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <Box className="flex-1 p-4">
      <Text className="text-2xl font-semibold mb-2">Your Profile</Text>
      <VStack space="md">
        <Input><InputField value={email} onChangeText={setEmail} placeholder="email"/></Input>
        <Input><InputField value={fullName} onChangeText={setFullName} placeholder="full name"/></Input>
        <Input><InputField value={avatarUrl} onChangeText={setAvatarUrl} placeholder="avatar url"/></Input>
        {ok ? <Text className="text-green-600">Saved.</Text> : null}
        {err ? <Text className="text-red-600">{err}</Text> : null}
        <Button className="bg-primary-600" onPress={save}>Save</Button>
      </VStack>
    </Box>
  );
}
