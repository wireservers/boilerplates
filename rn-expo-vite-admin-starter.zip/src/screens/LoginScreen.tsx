import React, { useState } from "react";
import { useAuth } from "../providers/AuthProvider";
import { Box, Button, Input, InputField, Text, VStack, HStack, Link } from "@gluestack-ui/themed";
import { useNavigation } from "@react-navigation/native";

export default function LoginScreen() {
  const { signIn, signUp } = useAuth();
  const nav = useNavigation<any>();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const doLogin = async () => {
    setBusy(true); setErr(null);
    try {
      await signIn(email, password);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const doSignup = async () => {
    setBusy(true); setErr(null);
    try {
      await signUp(email, password);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Box className="flex-1 items-center justify-center p-6 bg-brand-50">
      <VStack className="w-full max-w-md bg-white rounded-2xl p-6 shadow">
        <Text className="text-2xl font-semibold mb-2">Welcome back</Text>
        <Text className="text-gray-500 mb-4">Sign in to your admin workspace</Text>

        <VStack space="md">
          <Input>
            <InputField value={email} onChangeText={setEmail} placeholder="Email" autoCapitalize="none" keyboardType="email-address"/>
          </Input>
          <Input>
            <InputField value={password} onChangeText={setPassword} placeholder="Password" secureTextEntry/>
          </Input>

          {err ? <Text className="text-red-600">{err}</Text> : null}

          <Button onPress={doLogin} isDisabled={busy} className="bg-primary-600">Sign In</Button>
          <Button variant="outline" onPress={doSignup} isDisabled={busy}>Create Account</Button>

          <HStack className="justify-between mt-2">
            <Link onPress={() => nav.navigate("ForgotPassword")}>Forgot password?</Link>
          </HStack>
        </VStack>
      </VStack>
    </Box>
  );
}
