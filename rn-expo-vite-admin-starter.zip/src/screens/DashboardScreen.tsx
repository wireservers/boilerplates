import React from "react";
import { ScrollView, View } from "react-native";
import { Box, Text } from "@gluestack-ui/themed";
import StatsCard from "../components/StatsCard";
import Sparkline from "../components/charts/Sparkline";

const data = [12, 15, 11, 18, 22, 19, 25, 23, 28, 30, 26];

export default function DashboardScreen() {
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text className="text-2xl font-semibold mb-2">Dashboard</Text>
      <Text className="text-gray-500 mb-4">Overview of key metrics</Text>

      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        <StatsCard label="Active Users" value="1,248" footer="+4.2% WoW" />
        <StatsCard label="Signups" value="327" footer="+2.1% WoW" />
        <StatsCard label="Churn" value="1.8%" footer="-0.2% WoW" />
      </View>

      <Box className="bg-white rounded-2xl p-4 m-2 shadow">
        <Text className="text-lg font-semibold mb-2">Usage (14d)</Text>
        <Sparkline data={data} width={320} height={96} />
      </Box>
    </ScrollView>
  );
}
