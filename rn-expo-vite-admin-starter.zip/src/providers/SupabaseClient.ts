import { createClient } from "@supabase/supabase-js";
import "react-native-url-polyfill/auto";

const supabaseUrl = process.env.SUPABASE_URL || (global as any).process?.env?.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || (global as any).process?.env?.SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl as string, supabaseAnonKey as string, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});
