import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import * as Linking from "expo-linking";
import { supabase } from "./SupabaseClient";

type Session = import("@supabase/supabase-js").Session | null;

type AuthContextType = {
  session: Session;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  sendReset: (email: string) => Promise<void>;
  finishReset: (accessToken: string, newPassword: string) => Promise<void>;
};

const AuthContext = createContext<AuthContextType>(null as any);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  // Handle deep links for password reset
  useEffect(() => {
    const handler = ({ url }: { url: string }) => {
      // Expected: rnav://reset-password#access_token=... or ?code=type
      // Supabase deep link often uses access_token in hash
      if (url.includes("reset-password")) {
        // Nothing: the Reset screen parses the URL again.
      }
    };
    const sub = Linking.addEventListener("url", handler);
    return () => sub.remove();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) throw error;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  const sendReset = async (email: string) => {
    const redirectToWeb = "http://localhost:5173/reset-password";
    const redirectToNative = `${process.env.APP_SCHEME || "rnav"}://reset-password`;
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectToWeb,
    });
    if (error) throw error;
    // Native reset is supported when email is opened on device using OS routing.
  };

  const finishReset = async (accessToken: string, newPassword: string) => {
    const { error } = await supabase.auth.updateUser(
      { password: newPassword },
      { accessToken }
    as any);
    if (error) throw error;
  };

  return (
    <AuthContext.Provider value={{ session, loading, signIn, signUp, signOut, sendReset, finishReset }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
