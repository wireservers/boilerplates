export const brand = {
  primary: "#0ea5e9",
  primaryDark: "#0284c7",
  success: "#10b981",
  successDark: "#059669"
};
