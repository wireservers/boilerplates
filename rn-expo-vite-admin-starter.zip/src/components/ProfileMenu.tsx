import React, { useState, useEffect } from "react";
import { Menu, MenuItem, Button, Avatar, Box, Text } from "@gluestack-ui/themed";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../providers/AuthProvider";
import { supabase } from "../providers/SupabaseClient";

export default function ProfileMenu() {
  const { signOut, session } = useAuth();
  const nav = useNavigation<any>();
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      if (!session?.user) return;
      setEmail(session.user.email || null);
      const { data } = await supabase
        .from("profiles")
        .select("avatar_url")
        .eq("id", session.user.id)
        .single();
      setAvatarUrl(data?.avatar_url ?? null);
    };
    init();
  }, [session?.user?.id]);

  return (
    <Menu
      placement="bottom right"
      trigger={({ ...triggerProps }) => {
        return (
          <Button variant="link" {...triggerProps}>
            <Avatar size="sm" bgColor="$primary600">
              {avatarUrl ? <Avatar.Image source={{ uri: avatarUrl }} alt="avatar" /> : <Avatar.FallbackText>{email?.[0]?.toUpperCase() || "U"}</Avatar.FallbackText>}
            </Avatar>
          </Button>
        );
      }}
    >
      <MenuItem onPress={() => nav.navigate("Profile")}>
        <Text>Profile</Text>
      </MenuItem>
      <MenuItem onPress={() => nav.navigate("Settings")}>
        <Text>Settings</Text>
      </MenuItem>
      <MenuItem onPress={() => signOut()}>
        <Text>Logout</Text>
      </MenuItem>
    </Menu>
  );
}
