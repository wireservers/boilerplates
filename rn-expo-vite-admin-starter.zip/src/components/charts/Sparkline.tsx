import React from "react";
import { View } from "react-native";
import Svg, { Path } from "react-native-svg";

function makePath(data: number[], w: number, h: number) {
  if (!data.length) return "";
  const max = Math.max(...data);
  const min = Math.min(...data);
  const norm = (v: number) => (max === min ? 0.5 : (v - min) / (max - min));
  const stepX = w / (data.length - 1);
  return data
    .map((d, i) => {
      const x = i * stepX;
      const y = h - norm(d) * h;
      return `${i === 0 ? "M" : "L"} ${x} ${y}`;
    })
    .join(" ");
}

export default function Sparkline({ data = [], width = 160, height = 48 }: { data: number[]; width?: number; height?: number; }) {
  const d = makePath(data, width, height);
  return (
    <View style={{ width, height }}>
      <Svg width={width} height={height}>
        <Path d={d} fill="none" strokeWidth={2} />
      </Svg>
    </View>
  );
}
