import React from "react";
import { Box, Text } from "@gluestack-ui/themed";
import { View } from "react-native";

export default function StatsCard({ label, value, footer }: { label: string; value: string | number; footer?: string; }) {
  return (
    <Box className="bg-white rounded-2xl p-4 m-2 shadow" style={{ elevation: 2 }}>
      <Text className="text-gray-500">{label}</Text>
      <Text className="text-2xl font-semibold mt-1">{String(value)}</Text>
      {footer ? <Text className="text-xs text-gray-400 mt-1">{footer}</Text> : null}
    </Box>
  );
}
