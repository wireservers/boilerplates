import React from "react";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { useAuth } from "../providers/AuthProvider";
import LoginScreen from "../screens/LoginScreen";
import ForgotPasswordScreen from "../screens/ForgotPasswordScreen";
import ResetPasswordScreen from "../screens/ResetPasswordScreen";
import DashboardScreen from "../screens/DashboardScreen";
import UsersScreen from "../screens/UsersScreen";
import UserFormScreen from "../screens/UserFormScreen";
import ProfileScreen from "../screens/ProfileScreen";
import SettingsScreen from "../screens/SettingsScreen";
import { Pressable, View, Image } from "react-native";
import ProfileMenu from "../components/ProfileMenu";

const Stack = createNativeStackNavigator();
const Tabs = createBottomTabNavigator();

function AdminTabs() {
  return (
    <Tabs.Navigator>
      <Tabs.Screen name='Dashboard' component={DashboardScreen} />
      <Tabs.Screen name='Users' component={UsersScreen} />
      <Tabs.Screen name='Settings' component={SettingsScreen} />
    </Tabs.Navigator>
  );
}

export const RootNavigator = () => {
  const { session } = useAuth();

  return (
    <NavigationContainer theme={DefaultTheme}>
      <Stack.Navigator>
        {session ? (
          <Stack.Screen
            name='Admin'
            component={AdminTabs}
            options={{
              headerRight: () => (
                <View style={{ marginRight: 12 }}>
                  <ProfileMenu />
                </View>
              )
            }}
          />
        ) : (
          <>
            <Stack.Screen name='Login' component={LoginScreen} />
            <Stack.Screen name='ForgotPassword' component={ForgotPasswordScreen} options={{ title: "Forgot Password" }} />
            <Stack.Screen name='ResetPassword' component={ResetPasswordScreen} options={{ title: "Reset Password" }} />
          </>
        )}
        <Stack.Screen name='UserForm' component={UserFormScreen} options={{ title: "User" }} />
        <Stack.Screen name='Profile' component={ProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
