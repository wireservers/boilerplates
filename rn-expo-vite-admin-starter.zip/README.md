# React Native 18 + Expo + Vite — Admin Starter Kit (NativeWind + Gluestack UI + Supabase)

This starter delivers a cross‑platform admin template (iOS/Android/Web) with:

- Expo runtime for native and shared code.
- Vite for the **web** build using `react-native-web`.
- NativeWind (Tailwind for RN) + Gluestack UI for a modern green/blue design system.
- AuthN/AuthZ wired to **Supabase** (email/password) with login, logout, password reset, and profile edit.
- Avatar-driven profile menu (dropdown) that routes to **Profile** settings.
- **Dashboard** with responsive cards and a simple sparkline chart (RN SVG), styled by NativeWind.
- **Users Admin blade** with CRUD forms against a `profiles` table.
- Idiomatic navigation via React Navigation (auth stack + bottom tabs).

> **Tested flow**: Web via Vite, Native via Expo. One shared codebase.

---

## 0) Prerequisites

- Node 18+ and PNPM (`npm i -g pnpm`) or Yarn (use one).
- Expo CLI: `npm i -g expo` (or use `npx expo`).
- A Supabase project (free tier is fine).
- iOS: Xcode + Simulator; Android: Android Studio + Emulator.

> Versions are intentionally de‑pinned in `package.json`. Always run `npx expo install` after cloning to align native deps to the installed Expo SDK.

---

## 1) One‑time Setup

```bash
# 1) Extract project
unzip rn-expo-vite-admin-starter.zip -d ./
cd rn-expo-vite-admin-starter

# 2) Install deps
pnpm install

# 3) Align native peer deps to Expo SDK
npx expo install

# 4) Create env file
cp .env.example .env
```

Populate `.env`:

```bash
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
APP_SCHEME=rnav  # used for deep links
```

---

## 2) Supabase Configuration

1. **Enable email auth**: Authentication → Providers → Email, toggle **ON**.
2. **Deep link redirect** (password reset): Authentication → URL Configuration
   - **Site URL**: `http://localhost:5173` (web dev)
   - **Additional Redirect URLs**: `rnav://reset-password` (native scheme) and `http://localhost:5173/reset-password`
3. **SQL** → run the following to create `profiles` and permissive RLS for authenticated users:

```sql
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  full_name text,
  avatar_url text,
  role text default 'user',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "Profiles are viewable by owners" on public.profiles
for select using ( auth.uid() = id );

create policy "Owners can update their profile" on public.profiles
for update using ( auth.uid() = id );

create policy "Owners can insert their profile row" on public.profiles
for insert with check ( auth.uid() = id );
```

> In production, tighten these policies to match your governance posture.

---

## 3) Run the App

### Native (Expo)
```bash
pnpm dev:native
# choose iOS, Android, or run in Expo Go
```

### Web (Vite + RN Web)
```bash
pnpm dev:web
# open http://localhost:5173
```

---

## 4) Credentials Workflow

- **Sign up** on the Login screen (email/password).
- **Login** routes you to the tabbed Admin shell.
- Profile avatar (top-right) opens a dropdown with **Profile**, **Settings**, **Logout**.
- **Forgot password** triggers Supabase to email a reset link:
  - Web: lands on `/reset-password` and prompts for a new password.
  - Native: deep link `rnav://reset-password` opens the Reset screen.
- **Users** tab offers a simple Admin blade (list, create, edit, delete) against `profiles`.
  - Current user may edit **their** profile.
  - Admin behavior can evolve by tightening RLS or adding a service role API.

---

## 5) Architecture At‑a‑Glance

- Shared React Native components for all platforms.
- **Vite** aliases `react-native` → `react-native-web` for web builds.
- **NativeWind** delivers Tailwind‑style classes via RN StyleSheet.
- **Gluestack UI** provides accessible primitives with theme tokens.
- Charts implemented with `react-native-svg` for portability.

```
src/
  components/
  navigation/
  providers/
  screens/
  theme/
  index.ts
web/
  index.html
  main.tsx
```

---

## 6) Theming (Blue/Green Palette)

We ship a brand palette in `theme/tokens.ts` and wire it into Gluestack UI + NativeWind. Usage:

```tsx
<View className="bg-brand-600">
  <Text className="text-white">Brand Panel</Text>
</View>
<Button className="bg-primary-600">Save</Button>
```

---

## 7) Scripts

```bash
pnpm dev:native   # expo start
pnpm dev:web      # vite
pnpm build:web    # vite build
pnpm lint         # eslint
pnpm format       # prettier
```

---

## 8) Notes & Caveats

- If you add libraries with native code, run `npx expo prebuild` (bare) and re‑install pods.
- For production auth, configure a custom domain and strict RLS.
- This starter keeps charts minimal for portability. Swap for Victory/Recharts if your footprint allows (web‑only vs native).

---

## 9) What’s Included

- Login / Signup / Logout
- Password reset (deep link aware)
- Avatar + Profile dropdown → Profile page
- Dashboard with KPI cards + sparkline
- Users Admin blade (CRUD forms)
- Responsive, accessible components (RN + Web)

---

## 10) Next Steps

- Add role‑based views (`role` column).
- Add image upload for avatar via Supabase Storage + expo‑image‑picker.
- Harden RLS (admin APIs via service role, edge functions, etc.).

---

Happy shipping.
