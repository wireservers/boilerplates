import React from 'react';
import DashboardScreen from '../src/components/dashboard/DashboardScreen';

export default function DashboardPage() {
  return <DashboardScreen />;
}
