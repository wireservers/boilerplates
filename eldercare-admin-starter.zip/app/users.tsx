import React from 'react';
import UsersScreen from '../src/components/users/UsersScreen';

export default function UsersPage() {
  return <UsersScreen />;
}
